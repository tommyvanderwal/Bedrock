<script lang="ts">
	import { page } from '$app/stores';
	import { vms, nodes, events } from '$lib/stores';
	import { goto } from '$app/navigation';
	import { apiGet, vmStart, vmShutdown, vmPoweroff, vmMigrate, vmDelete,
		vmBackup, vmBackupsList, vmBackupDelete, vmRestore,
		listBackupTargets,
		setBackupSchedule, removeBackupSchedule, cronPreview,
		type VmBackup } from '$lib/api';
	import Chart from '$lib/Chart.svelte';
	import LogList from '$lib/LogList.svelte';

	let vmName = $derived($page.params.name);
	let vm = $derived($vms[vmName]);
	let node = $derived(vm?.running_on ? $nodes[vm.running_on] : null);

	let metrics = $state<any>({});
	let seededLogs = $state<any[]>([]);
	let liveLogs = $state<any[]>([]);
	// Live mgmt events mentioning this VM + seeded history.
	let logs = $derived([...liveLogs, ...seededLogs].slice(0, 50));
	let actionStatus = $state('');
	let converting = $state(false);

	let replicaCount = $derived(vm?.defined_on?.length ?? 1);
	let isPet = $derived(replicaCount >= 2);  // drives Migrate button enabled/disabled

	// Backup state — populated on mount + after each backup completes.
	let backups = $state<VmBackup[]>([]);
	let lastBackupError = $state<{ts_index: number; target_id: string; reason: string} | null>(null);
	let backupTargetId = $state('main');
	let hasBackupTarget = $state(false);
	let backingUp = $state(false);

	// Delete confirmation — Proxmox-style modal. Click Delete → modal shows
	// the VM name; operator types "delete" (literal word) to enable the
	// final Delete button. No upfront confirm() popup.
	let deleteModalOpen = $state(false);
	let deleteTyped = $state('');

	function openDeleteModal() {
		deleteTyped = '';
		deleteModalOpen = true;
	}
	function closeDeleteModal() {
		deleteModalOpen = false;
		deleteTyped = '';
	}
	async function confirmDelete() {
		if (deleteTyped !== 'delete') return;
		deleteModalOpen = false;
		converting = true;
		try {
			await vmDelete(vmName);
			goto('/vms');
		} catch (e: any) {
			actionStatus = `Delete failed: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
			converting = false;
		}
	}

	async function doAction(fn: () => Promise<any>, label: string) {
		actionStatus = `${label}...`;
		try {
			const r = await fn();
			actionStatus = `${label}: ${r.status || 'done'}${r.duration_s ? ` (${r.duration_s}s)` : ''}`;
			setTimeout(() => actionStatus = '', 5000);
		} catch (e: any) {
			actionStatus = `${label} failed: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		}
	}

	async function fetchMetrics(name: string) {
		try {
			const allVm = await apiGet('/api/metrics/vms?hours=1&step=15s');
			const filtered: any = {};
			for (const [metricName, series] of Object.entries(allVm)) {
				filtered[metricName] = {};
				if (series && typeof series === 'object') {
					for (const [label, points] of Object.entries(series as any)) {
						if (label.includes(name)) filtered[metricName][label] = points;
					}
				}
			}
			metrics = filtered;
		} catch (e) { /* not ready */ }
	}

	async function fetchSeededLogs(name: string) {
		try {
			const r = await apiGet(`/api/logs/vm/${name}?limit=50&hours=4`);
			seededLogs = r.sort((a: any, b: any) => (b._time || '').localeCompare(a._time || ''));
		} catch (e) { /* keep whatever we have */ }
	}

	async function fetchBackups(name: string) {
		try {
			const r = await vmBackupsList(name);
			backups = r.backups || [];
			lastBackupError = r.last_backup_error || null;
		} catch (e) { /* not ready */ }
	}

	// ── Schedule state ──
	// `vm.backup_schedule` is folded into cluster.json; we read it
	// straight from the live `vm` object.
	let scheduleInput = $state('');
	let schedulePreview = $state<string[]>([]);
	let schedulePreviewError = $state<string | null>(null);
	let scheduleSaving = $state(false);

	let activeSchedule = $derived(vm?.backup_schedule);

	// Debounced cron-preview lookup as the operator types.
	let previewTimer: any = null;
	function onScheduleInput() {
		schedulePreviewError = null;
		if (previewTimer) clearTimeout(previewTimer);
		const expr = scheduleInput.trim();
		if (!expr) { schedulePreview = []; return; }
		previewTimer = setTimeout(async () => {
			try {
				const r = await cronPreview(expr, 5);
				schedulePreview = r.next_fires_utc;
				schedulePreviewError = null;
			} catch (e: any) {
				schedulePreview = [];
				schedulePreviewError = e.message.replace(/^\d+: /, '');
			}
		}, 300);
	}

	async function saveSchedule() {
		if (!scheduleInput.trim()) {
			actionStatus = 'Cron expression is empty.';
			setTimeout(() => actionStatus = '', 4000);
			return;
		}
		scheduleSaving = true;
		try {
			await setBackupSchedule(vmName, {
				target_id: backupTargetId,
				cron_expr: scheduleInput.trim(),
			});
			actionStatus = 'Schedule saved.';
			scheduleInput = '';
			schedulePreview = [];
			setTimeout(() => actionStatus = '', 4000);
		} catch (e: any) {
			actionStatus = `Schedule save failed: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		} finally {
			scheduleSaving = false;
		}
	}

	async function clearSchedule() {
		if (!confirm(`Remove the backup schedule for ${vmName}?`)) return;
		try {
			await removeBackupSchedule(vmName, 'cleared via dashboard');
			actionStatus = 'Schedule cleared.';
			setTimeout(() => actionStatus = '', 4000);
		} catch (e: any) {
			actionStatus = `Schedule remove failed: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		}
	}

	// Re-preview the EXISTING schedule's next runs (read-only display).
	let activeNextRuns = $state<string[]>([]);
	let lastPreviewedExpr = '';
	$effect(() => {
		const cur = activeSchedule?.cron_expr || '';
		if (cur && cur !== lastPreviewedExpr) {
			lastPreviewedExpr = cur;
			cronPreview(cur, 5).then(r => activeNextRuns = r.next_fires_utc).catch(() => activeNextRuns = []);
		} else if (!cur) {
			activeNextRuns = [];
			lastPreviewedExpr = '';
		}
	});

	async function fetchBackupTargets() {
		try {
			const r = await listBackupTargets();
			const ids = Object.keys(r.targets || {});
			hasBackupTarget = ids.length > 0;
			if (ids.length > 0 && !ids.includes(backupTargetId)) {
				backupTargetId = ids[0];
			}
		} catch (e) {
			hasBackupTarget = false;
		}
	}

	async function startBackup() {
		if (backingUp || !hasBackupTarget) return;
		backingUp = true;
		actionStatus = 'Backup queued — running on home node...';
		try {
			await vmBackup(vmName, backupTargetId);
			// Backup is fire-and-forget; live updates land via the WS task
			// channel. We just refresh the history shortly to catch the
			// fast cases (small VM / warm cache).
			setTimeout(() => fetchBackups(vmName), 5000);
			actionStatus = 'Backup started — see Tasks tab for progress';
			setTimeout(() => actionStatus = '', 6000);
		} catch (e: any) {
			actionStatus = `Backup failed to start: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		} finally {
			backingUp = false;
		}
	}

	async function deleteBackup(snapshotId: string) {
		if (!confirm(`Delete kopia snapshot ${snapshotId}? This cannot be undone.`)) return;
		try {
			await vmBackupDelete(vmName, snapshotId, { target_id: backupTargetId });
			await fetchBackups(vmName);
		} catch (e: any) {
			actionStatus = `Delete backup failed: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		}
	}

	// Restore-confirm modal — destructive write to the LV; require typing
	// the VM name. Same pattern as the Delete VM modal so the operator's
	// muscle memory is consistent.
	let restoreModal = $state<VmBackup | null>(null);
	let restoreTyped = $state('');

	function openRestoreModal(b: VmBackup) {
		restoreModal = b;
		restoreTyped = '';
	}
	function closeRestoreModal() {
		restoreModal = null;
		restoreTyped = '';
	}

	async function confirmRestore() {
		if (!restoreModal) return;
		if (restoreTyped !== vmName) return;
		const b = restoreModal;
		restoreModal = null;
		actionStatus = `Restore queued for snapshot ${b.kopia_snapshot_id.slice(0,12)}…`;
		try {
			await vmRestore(vmName, {
				target_id: b.target_id,
				kopia_snapshot_id: b.kopia_snapshot_id,
			});
			actionStatus = 'Restore started — see Tasks tab for progress';
			setTimeout(() => fetchBackups(vmName), 5000);
			setTimeout(() => actionStatus = '', 8000);
		} catch (e: any) {
			actionStatus = `Restore failed to start: ${e.message}`;
			setTimeout(() => actionStatus = '', 8000);
		}
	}

	function fmtBytes(n: number): string {
		if (!n) return '-';
		if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)} GiB`;
		if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(1)} MiB`;
		if (n >= 1024) return `${(n / 1024).toFixed(0)} KiB`;
		return `${n} B`;
	}

	// Rebinds on route param change — previous setInterval + store subscription
	// are cleaned up so a navigation /vm/A → /vm/B doesn't leave stale filters.
	$effect(() => {
		const name = vmName;  // reactive dep
		metrics = {};
		seededLogs = [];
		liveLogs = [];
		backups = [];
		lastBackupError = null;
		fetchMetrics(name);
		fetchSeededLogs(name);
		fetchBackups(name);
		fetchBackupTargets();
		const iv = setInterval(() => fetchMetrics(name), 15000);
		// Cheap poll for backup history — covers task-completion races
		// without subscribing to the task WS channel here.
		const ivb = setInterval(() => fetchBackups(name), 20000);
		const unsub = events.subscribe(all => {
			liveLogs = all.filter((e: any) => (e._msg || '').includes(name));
		});
		return () => { clearInterval(iv); clearInterval(ivb); unsub(); };
	});
</script>

<svelte:head><title>VM: {vmName}</title></svelte:head>

<div class="breadcrumb">
	<a href="/">Overview</a> / <strong>{vmName}</strong>
</div>

{#if vm}
<div class="header">
	<h1>{vmName}</h1>
	<span class="tag" class:running={vm.state === 'running'} class:off={vm.state !== 'running'}>
		{vm.state}
	</span>
	{#if actionStatus}
		<span class="toast">{actionStatus}</span>
	{/if}
</div>

<div class="info-grid">
	<div class="info-card">
		<h3>Virtual Machine</h3>
		<div class="stat"><span>State</span><span>{vm.state}</span></div>
		<div class="stat"><span>Running on</span>
			<span>{#if vm.running_on}<a href="/node/{vm.running_on}">{vm.running_on}</a>{:else}-{/if}</span>
		</div>
		<div class="stat"><span>Backup node</span>
			<span>{#if vm.backup_node}<a href="/node/{vm.backup_node}">{vm.backup_node}</a>{:else}-{/if}</span>
		</div>
	</div>
	<div class="info-card">
		<h3>Disks ({vm.disks?.length ?? 0})</h3>
		{#if vm.disks && vm.disks.length > 0}
			<table class="disks-table">
				<thead>
					<tr><th>Target</th><th>Size</th><th>DRBD</th><th>State</th></tr>
				</thead>
				<tbody>
					{#each vm.disks as d}
						<tr>
							<td><code>{d.target}</code></td>
							<td>{d.size_gb ?? '?'} G</td>
							<td>
								{#if d.drbd_resource}
									<code class="drbd-res">{d.drbd_resource}</code>
									<span class="sub">minor {d.drbd_minor}</span>
								{:else}
									<span class="muted">local</span>
								{/if}
							</td>
							<td>
								{#if d.drbd_resource}
									<span class="tag" class:primary={d.drbd_role === 'Primary'}
										class:secondary={d.drbd_role !== 'Primary'}>
										{d.drbd_role || '-'}
									</span>
									<span class="tag" class:uptodate={d.drbd_disk === 'UpToDate'}
										class:syncing={d.drbd_disk && d.drbd_disk !== 'UpToDate'}>
										{d.drbd_disk || '-'}
									</span>
									{#if d.drbd_sync_pct}<span class="sub">{d.drbd_sync_pct}%</span>{/if}
								{:else}
									<span class="muted">—</span>
								{/if}
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		{:else}
			<p class="muted">No disks reported.</p>
		{/if}
	</div>
	<div class="info-card">
		<h3>Actions</h3>
		<div class="actions">
			<button class="btn start" disabled={vm.state === 'running'}
				onclick={() => doAction(() => vmStart(vmName), 'Start')}>Start</button>
			<button class="btn migrate" disabled={vm.state !== 'running' || !isPet}
				title={!isPet ? 'Migration requires PET or ViPet (DRBD replication)' : ''}
				onclick={() => doAction(() => vmMigrate(vmName), 'Migrate')}>Live Migrate</button>
			<button class="btn stop" disabled={vm.state !== 'running'}
				onclick={() => doAction(() => vmShutdown(vmName), 'Shutdown')}>Shutdown</button>
			<button class="btn poweroff" disabled={vm.state !== 'running'}
				onclick={() => doAction(() => vmPoweroff(vmName), 'Power Off')}>Power Off</button>
			{#if vm.state === 'running' && vm.vnc_ws_url}
				<a href="/console/{vmName}" class="btn console">Open Console</a>
			{/if}
			<button class="btn backup" disabled={backingUp || !hasBackupTarget}
				title={hasBackupTarget
					? 'Take an LV snapshot and push it to the kopia repository'
					: 'No backup target configured — set one with `bedrock backup target set`'}
				onclick={startBackup}>{backingUp ? 'Backup...' : 'Backup'}</button>
			<a href="/vm/{vmName}/settings" class="btn settings">Settings</a>
			<button class="btn delete" disabled={converting}
				title="Stop, tear down DRBD, remove LVs, drop from inventory"
				onclick={openDeleteModal}>Delete VM</button>
		</div>
	</div>
</div>

<h2>Backups</h2>
<div class="info-card backups-card">
	{#if !hasBackupTarget}
		<p class="muted">
			No backup target configured. On the mgmt master, drop
			<code>/etc/bedrock/backup.key</code> (32+ random bytes, mode 0600)
			and <code>/etc/bedrock/backup-credentials/&lt;target&gt;.env</code>,
			then call <code>POST /api/backup/targets</code>.
		</p>
	{:else}
		<div class="backups-head">
			<span class="muted">Target:</span> <code>{backupTargetId}</code>
			<span class="muted" style="margin-left: 16px;">{backups.length} snapshot{backups.length === 1 ? '' : 's'}</span>
		</div>

		<!-- Schedule subsection -->
		<div class="schedule-block">
			<h4>Schedule</h4>
			{#if activeSchedule}
				<div class="schedule-active">
					<span class="muted">Cron (UTC):</span>
					<code>{activeSchedule.cron_expr}</code>
					<span class="muted">→ target</span>
					<code>{activeSchedule.target_id}</code>
					<button class="btn-small danger" onclick={clearSchedule}>Remove schedule</button>
				</div>
				{#if activeNextRuns.length > 0}
					<div class="schedule-preview">
						<span class="muted">Next 5 runs (UTC):</span>
						<ul>
							{#each activeNextRuns as t}<li><code>{t}</code></li>{/each}
						</ul>
					</div>
				{/if}
			{:else}
				<div class="schedule-form">
					<input type="text" bind:value={scheduleInput} oninput={onScheduleInput}
						placeholder="0 2 * * *  (daily 02:00 UTC)  •  @daily  •  */15 * * * *" />
					<button class="btn-small primary" disabled={scheduleSaving || !scheduleInput.trim() || !!schedulePreviewError}
						onclick={saveSchedule}>{scheduleSaving ? 'Saving…' : 'Save schedule'}</button>
				</div>
				{#if schedulePreviewError}
					<div class="schedule-err">⚠ {schedulePreviewError}</div>
				{:else if schedulePreview.length > 0}
					<div class="schedule-preview">
						<span class="muted">Next 5 runs (UTC):</span>
						<ul>
							{#each schedulePreview as t}<li><code>{t}</code></li>{/each}
						</ul>
					</div>
				{/if}
				<p class="schedule-note muted">
					All times are UTC. Cron syntax: <code>m h dom mon dow</code> or one of
					<code>@hourly</code> / <code>@daily</code> / <code>@weekly</code> / <code>@monthly</code>.
					The mgmt master fires the backup; on master change the schedule keeps running.
				</p>
			{/if}
		</div>
		{#if lastBackupError}
			<div class="backup-error">
				Last backup error: <code>{lastBackupError.target_id}</code> — {lastBackupError.reason}
			</div>
		{/if}
		{#if backups.length > 0}
			<table class="disks-table">
				<thead>
					<tr>
						<th>Snapshot</th>
						<th>Disks</th>
						<th>Quiesce</th>
						<th>Target</th>
						<th>Size added</th>
						<th>Duration</th>
						<th>Source node</th>
						<th>Label</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					{#each backups as b}
						<tr>
							<td><code title={b.kopia_snapshot_id}>{b.kopia_snapshot_id.slice(0, 12)}…</code></td>
							<td>
								{#if b.disks && b.disks.length > 1}
									<span class="pill multi" title={b.disks.map(d => `${d.target_dev}=${d.kopia_snapshot_id.slice(0,8)}…`).join('\n')}>{b.disks.length} disks</span>
								{:else}
									<span class="muted">{b.disks?.[0]?.target_dev || 'disk0'}</span>
								{/if}
							</td>
							<td>
								{#if b.fs_freeze_used}
									<span class="pill ok" title="virsh domfsfreeze succeeded — guest filesystems were quiesced before snapshot">fs-freeze</span>
								{:else}
									<span class="pill warn" title="VM was off, or no qemu-guest-agent — snapshot is crash-consistent only">crash-consistent</span>
								{/if}
							</td>
							<td>{b.target_id}</td>
							<td>{fmtBytes(b.bytes_added)}</td>
							<td>{b.duration_s ? `${b.duration_s.toFixed(1)}s` : '-'}</td>
							<td>{b.source_node || '-'}</td>
							<td>{#if b.label}{b.label}{:else}<span class="muted">—</span>{/if}</td>
							<td class="row-actions">
								<button class="btn-small primary" disabled={vm.state === 'running'}
									title={vm.state === 'running'
										? 'Shut the VM down before restoring (qemu would race the disk write)'
										: 'Stream this snapshot back onto the VM disk(s)'}
									onclick={() => openRestoreModal(b)}>Restore</button>
								<button class="btn-small danger" onclick={() => deleteBackup(b.kopia_snapshot_id)}>Delete</button>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		{:else}
			<p class="muted">No backups yet. Click <strong>Backup</strong> above to take one.</p>
		{/if}
	{/if}
</div>

{#if Object.values(metrics.cpu || {}).length > 0}
<h2>Performance (1h)</h2>
<div class="charts-grid">
	<Chart title="CPU %" data={metrics.cpu || {}} series={Object.keys(metrics.cpu || {})} width={440} height={160} />
	<Chart title="Disk Write IOPS" data={metrics.disk_wr_iops || {}} series={Object.keys(metrics.disk_wr_iops || {})} width={440} height={160} />
	<Chart title="Disk Write Latency (ms)" data={metrics.disk_wr_lat || {}} series={Object.keys(metrics.disk_wr_lat || {})} width={440} height={160} />
	<Chart title="Disk Read IOPS" data={metrics.disk_rd_iops || {}} series={Object.keys(metrics.disk_rd_iops || {})} width={440} height={160} />
</div>
{/if}

<h2>Recent Logs</h2>
<LogList {logs} />

{:else}
<p>VM not found: {vmName}</p>
{/if}

{#if deleteModalOpen}
	<div class="modal-bg" role="presentation" onclick={closeDeleteModal}>
		<div class="modal" role="dialog" aria-modal="true"
			onclick={(e) => e.stopPropagation()}
			onkeydown={(e) => { if (e.key === 'Escape') closeDeleteModal(); }}>
			<h3>Delete VM</h3>
			<p class="del-vm-name">{vmName}</p>
			<p class="del-warn">
				Stops the VM, tears down any DRBD resource, and removes the disk LVs
				on every node. This cannot be undone.
			</p>
			<label class="del-label">
				Type <code>delete</code> to confirm:
				<input type="text" bind:value={deleteTyped} autocomplete="off"
					autofocus
					onkeydown={(e) => { if (e.key === 'Enter' && deleteTyped === 'delete') confirmDelete(); }} />
			</label>
			<div class="del-actions">
				<button class="btn" onclick={closeDeleteModal}>Cancel</button>
				<button class="btn btn-danger" disabled={deleteTyped !== 'delete'}
					onclick={confirmDelete}>Delete</button>
			</div>
		</div>
	</div>
{/if}

{#if restoreModal}
	<div class="modal-bg" role="presentation" onclick={closeRestoreModal}>
		<div class="modal" role="dialog" aria-modal="true"
			onclick={(e) => e.stopPropagation()}
			onkeydown={(e) => { if (e.key === 'Escape') closeRestoreModal(); }}>
			<h3>Restore VM from snapshot</h3>
			<p class="del-vm-name">{vmName}</p>
			<dl class="restore-meta">
				<dt>Backup ID</dt><dd><code title={restoreModal.kopia_snapshot_id}>{restoreModal.kopia_snapshot_id}</code></dd>
				<dt>Target</dt><dd><code>{restoreModal.target_id}</code></dd>
				<dt>Label</dt><dd>{restoreModal.label || '—'}</dd>
				<dt>Source node</dt><dd>{restoreModal.source_node || '—'}</dd>
				<dt>Size added</dt><dd>{fmtBytes(restoreModal.bytes_added)}</dd>
				<dt>Quiesce</dt><dd>{restoreModal.fs_freeze_used ? 'fs-freeze (consistent)' : 'crash-consistent'}</dd>
				<dt>Disks ({restoreModal.disks?.length ?? 1})</dt>
				<dd>
					{#if restoreModal.disks && restoreModal.disks.length > 0}
						<ul class="restore-disks">
							{#each restoreModal.disks as d}
								<li>
									<code>{d.target_dev}</code> →
									<code title={d.kopia_snapshot_id}>{d.kopia_snapshot_id.slice(0,12)}…</code>
									<span class="muted">({fmtBytes(d.bytes_added)})</span>
								</li>
							{/each}
						</ul>
					{:else}
						<span class="muted">single disk (legacy backup record)</span>
					{/if}
				</dd>
			</dl>
			<p class="del-warn">
				All <strong>{restoreModal.disks?.length ?? 1}</strong> disk(s) will be
				streamed back onto <code>{vmName}</code>'s LVs in one operation.
				<strong>Anything written to any of these disks since this backup
				will be lost.</strong> The VM must be shut down first — qemu holding
				a disk would race with the restore writes.
			</p>
			<label class="del-label">
				Type the VM name <code>{vmName}</code> to confirm:
				<input type="text" bind:value={restoreTyped} autocomplete="off"
					autofocus
					onkeydown={(e) => { if (e.key === 'Enter' && restoreTyped === vmName) confirmRestore(); }} />
			</label>
			<div class="del-actions">
				<button class="btn" onclick={closeRestoreModal}>Cancel</button>
				<button class="btn btn-danger" disabled={restoreTyped !== vmName}
					onclick={confirmRestore}>Restore</button>
			</div>
		</div>
	</div>
{/if}

<style>
	.breadcrumb { font-size: 13px; color: #8b949e; margin-bottom: 12px; }
	.header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
	h1 { font-size: 24px; margin: 0; }
	h2 { font-size: 14px; color: #8b949e; text-transform: uppercase; letter-spacing: 1px; margin: 20px 0 10px; }
	h3 { font-size: 13px; color: #8b949e; margin: 0 0 8px; text-transform: uppercase; }
	.tag { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
	.tag.running, .tag.uptodate { background: #1a7f37; color: #fff; }
	.tag.off { background: #6e7681; color: #fff; }
	.tag.primary { background: #1f6feb; color: #fff; }
	.tag.secondary { background: #30363d; color: #8b949e; }
	.tag.syncing { background: #d29922; color: #000; }
	.toast { margin-left: auto; background: #21262d; border: 1px solid #30363d; border-radius: 6px; padding: 4px 12px; font-size: 12px; }

	.info-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px; }
	.info-card { background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }
	.stat { display: flex; justify-content: space-between; font-size: 13px; margin: 4px 0; }
	.stat span:first-child { color: #8b949e; }
	.charts-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(440px, 1fr)); gap: 12px; }

	.actions { display: flex; gap: 8px; flex-wrap: wrap; }
	.btn { padding: 6px 14px; border: 1px solid #30363d; border-radius: 6px; background: #21262d; color: #e6edf3; font-size: 13px; cursor: pointer; }
	.btn:hover { background: #30363d; text-decoration: none; }
	.btn:disabled { opacity: 0.3; cursor: not-allowed; }
	.btn.start { border-color: #1a7f37; color: #3fb950; }
	.btn.migrate { border-color: #1f6feb; color: #58a6ff; }
	.btn.stop { border-color: #d29922; color: #d29922; }
	.btn.poweroff { border-color: #f85149; color: #f85149; }
	.btn.console { border-color: #8957e5; color: #bc8cff; }
	.btn.settings { border-color: #6e7681; color: #c9d1d9; margin-left: auto; }
	.btn.settings:hover { background: #30363d; text-decoration: none; }
	.btn.delete { border-color: #f85149; color: #f85149; }
	.btn.delete:hover:not(:disabled) { background: #f8514922; }
	.btn.backup { border-color: #d29922; color: #f0c674; }
	.btn.backup:hover:not(:disabled) { background: #d2992222; }

	.backups-card { padding: 12px 16px; }

	.schedule-block {
		margin: 12px 0; padding: 10px 12px;
		background: #0d1117; border: 1px solid #21262d; border-radius: 6px;
	}
	.schedule-block h4 {
		margin: 0 0 8px; font-size: 11px; color: #8b949e;
		text-transform: uppercase; letter-spacing: 1px; font-weight: 500;
	}
	.schedule-active {
		display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
		font-size: 12px;
	}
	.schedule-active code {
		background: #21262d; padding: 1px 6px; border-radius: 3px; font-size: 11px;
	}
	.schedule-form {
		display: flex; gap: 8px; align-items: center;
	}
	.schedule-form input {
		flex: 1; background: #161b22; border: 1px solid #30363d;
		border-radius: 6px; padding: 6px 10px; color: #e6edf3; font-size: 13px;
		font-family: ui-monospace, SFMono-Regular, monospace;
	}
	.schedule-form input:focus { outline: none; border-color: #58a6ff; }
	.schedule-preview { margin-top: 8px; font-size: 11px; }
	.schedule-preview ul { list-style: none; margin: 4px 0 0; padding: 0; }
	.schedule-preview li { padding: 1px 0; }
	.schedule-preview code {
		background: #21262d; padding: 1px 5px; border-radius: 3px;
		font-size: 11px; color: #c9d1d9;
	}
	.schedule-err {
		margin-top: 6px; font-size: 12px; color: #f85149;
	}
	.schedule-note { margin: 8px 0 0; font-size: 11px; }
	.schedule-note code {
		background: #21262d; padding: 1px 5px; border-radius: 3px;
		font-size: 10px;
	}
	.backups-head { font-size: 12px; margin-bottom: 8px; }
	.backup-error {
		font-size: 12px; color: #f85149; background: #f8514911;
		border-left: 3px solid #f85149; padding: 6px 10px; margin: 6px 0 10px;
	}
	.btn-small {
		padding: 2px 8px; border: 1px solid #30363d; border-radius: 4px;
		background: #21262d; color: #8b949e; font-size: 11px; cursor: pointer;
		margin-right: 4px;
	}
	.btn-small:hover:not(:disabled) { background: #30363d; }
	.btn-small:disabled { opacity: 0.4; cursor: not-allowed; }
	.btn-small.danger:hover:not(:disabled) { color: #f85149; border-color: #f85149; }
	.btn-small.primary { border-color: #1f6feb; color: #58a6ff; }
	.btn-small.primary:hover:not(:disabled) { background: #1f6feb22; color: #fff; }
	.row-actions { white-space: nowrap; }

	.restore-meta {
		display: grid; grid-template-columns: 110px 1fr; gap: 4px 12px;
		font-size: 12px; margin: 0 0 12px;
	}
	.restore-meta dt { color: #8b949e; }
	.restore-meta dd { margin: 0; color: #c9d1d9; }
	.restore-meta code {
		background: #0d1117; padding: 1px 6px; border-radius: 3px; font-size: 11px;
	}
	.restore-disks { list-style: none; margin: 0; padding: 0; font-size: 12px; }
	.restore-disks li { padding: 2px 0; }

	.pill {
		display: inline-block; padding: 1px 8px; border-radius: 10px; font-size: 11px;
	}
	.pill.ok { background: #1a7f3733; color: #3fb950; }
	.pill.warn { background: #d2992233; color: #d29922; }
	.pill.multi { background: #1f6feb33; color: #58a6ff; cursor: help; }

	.ha-check { display: flex; align-items: center; gap: 8px; font-size: 13px; margin: 6px 0; cursor: pointer; }
	.ha-check.nested { margin-left: 20px; }
	.ha-check.disabled { opacity: 0.4; cursor: not-allowed; }
	.ha-check input { accent-color: #58a6ff; cursor: inherit; }
	.ha-check .hint { font-style: italic; color: #8b949e; font-size: 11px; }
	.ha-note { font-size: 11px; color: #8b949e; margin: 8px 0 0; }
	.ha-note code { background: #21262d; padding: 1px 6px; border-radius: 3px; color: #e6edf3; }

	/* Disks table in the info card */
	.disks-table { width: 100%; border-collapse: collapse; font-size: 12px; }
	.disks-table th, .disks-table td { text-align: left; padding: 4px 6px; }
	.disks-table th { color: #8b949e; font-weight: 500; border-bottom: 1px solid #30363d; }
	.disks-table td code { background: #21262d; padding: 1px 5px; border-radius: 3px; font-size: 11px; }
	.disks-table .drbd-res { font-size: 11px; }
	.sub { color: #6e7681; font-size: 11px; margin-left: 4px; }
	.muted { color: #6e7681; }

	/* Delete confirmation modal (Proxmox-style) */
	.modal-bg {
		position: fixed; inset: 0; background: #0008; backdrop-filter: blur(2px);
		display: flex; align-items: center; justify-content: center; z-index: 1000;
	}
	.modal {
		background: #161b22; border: 1px solid #30363d; border-radius: 8px;
		padding: 24px; min-width: 420px; max-width: 560px;
	}
	.modal h3 {
		font-size: 16px; color: #e6edf3; text-transform: none; letter-spacing: 0;
		margin: 0 0 8px;
	}
	.del-vm-name {
		font-family: ui-monospace, SFMono-Regular, monospace;
		font-size: 18px; font-weight: 600; color: #e6edf3;
		background: #0d1117; border: 1px solid #30363d; border-radius: 6px;
		padding: 8px 12px; margin: 4px 0 12px;
	}
	.del-warn {
		font-size: 13px; color: #d29922; background: #d2992211;
		border-left: 3px solid #d29922; padding: 8px 12px; margin: 0 0 16px;
	}
	.del-label { display: block; font-size: 13px; color: #c9d1d9; margin-bottom: 12px; }
	.del-label code { background: #21262d; padding: 1px 6px; border-radius: 3px; color: #f85149; font-weight: 600; }
	.del-label input {
		display: block; width: 100%; margin-top: 6px;
		background: #0d1117; border: 1px solid #30363d; border-radius: 6px;
		padding: 8px 12px; color: #e6edf3; font-size: 14px;
		font-family: ui-monospace, SFMono-Regular, monospace;
	}
	.del-label input:focus { outline: none; border-color: #58a6ff; }
	.del-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px; }
	.btn-danger { border-color: #f85149; color: #fff; background: #da3633; }
	.btn-danger:hover:not(:disabled) { background: #f85149; }
	.btn-danger:disabled { background: #30363d; color: #6e7681; border-color: #30363d; }
</style>
